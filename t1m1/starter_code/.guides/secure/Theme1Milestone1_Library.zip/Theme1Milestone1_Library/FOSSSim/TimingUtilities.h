// Note that these utilities probably won't work with windows. If you write 
// some alternative code that works with windows, send it to me!

#ifndef __TIMING_UTILS_H__
#define __TIMING_UTILS_H__

#include <time.h>
#include <sys/time.h>
#include <iostream>

namespace timingutils 
{
    
    double seconds();
    
}

#endif

