Array3d v(1,2,3);
cout << v.exp() << endl;
