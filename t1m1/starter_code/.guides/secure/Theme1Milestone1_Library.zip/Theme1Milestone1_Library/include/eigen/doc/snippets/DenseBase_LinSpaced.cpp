cout << VectorXi::LinSpaced(7,10,4).transpose() << endl;
cout << VectorXd::LinSpaced(0.0,1.0,5).transpose() << endl;
